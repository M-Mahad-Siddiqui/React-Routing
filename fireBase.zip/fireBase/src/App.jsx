import Loginn from "./pages/Loginn"
function App() {

  return (
    <>
      <Loginn/>
    </>
  )
}

export default App
