import AppRouter from "./routes/AppRouter";

export default function App() {
  return (
    <main className="">
      <AppRouter />
    </main>
  );
}
